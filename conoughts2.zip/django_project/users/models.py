from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
# Create your models here.

class Profilem(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='icecream.jpg', upload_to='profile_pics')
    def __str__(self):
        return f'{self.user.username } Profile'

class feedback(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    content=models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f'{self.sender.username } Feedback'
    def get_absolute_url(self):
        return reverse('profile')

class report(models.Model):
    list_display = ('sender', 'against','msg','dates')
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    against = models.IntegerField()
    msg = models.TextField()
    date_posted=models.DateTimeField(default=timezone.now)
    def __str__(self):
        return f'{self.against } s Report'

