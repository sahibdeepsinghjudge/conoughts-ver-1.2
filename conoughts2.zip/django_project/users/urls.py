from django.urls import path
from . import views
from .views import FeedbackCreateView,ReportCreateView

urlpatterns = [
    path('', views.home, name='register'), 
    path('feedback', FeedbackCreateView.as_view(), name='feedback'), 
    path('report', ReportCreateView.as_view(), name='report'),
    path('feedback/users',views.allfeedbacks, name='fb-views'), 
    path('report/users',views.allreports, name='rp-views'),
    path('PrivacyPolicy',views.privacy, name='privacy'),
    path('user/detail/external', views.userext, name='user-ext'),
    path('user/action',views.action,name='action'),
    path('story/search',views.seastory,name='storys'),
    path('search',views.search,name='search'),
    path('usersearch',views.usearch, name='usearch'),
    path('story',views.ssearch, name='ssearch'),
]