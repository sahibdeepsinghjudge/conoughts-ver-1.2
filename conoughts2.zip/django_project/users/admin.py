from django.contrib import admin
from .models import Profilem,feedback,report
# Register your models here.
admin.site.register(Profilem)
admin.site.register(feedback)
admin.site.register(report)


