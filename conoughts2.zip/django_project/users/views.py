from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .forms import UserRegisterForm,UserUpdateForm,ProfileUpdateForm
from django.contrib import messages
from blog.models import Story,thoughts
from django.views.generic import CreateView
from .models import feedback,report
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.db.models import Q
# Create your views here.
def home(request):
        if request.method == 'POST':
            form=UserRegisterForm(request.POST)
            if form.is_valid():
                    messages.success(request, f' "Your Account has been created" !')
                    form.save()
                    return redirect('login')
            else:
                messages.warning(request, f'Please solve the Error !')     
        else:
            form = UserRegisterForm()
        return render(request,'users/tregister.html',{'header':'Register','form':form})

@login_required
def profile(request):
        if request.method == 'POST':
                u_form = UserUpdateForm(request.POST,instance=request.user)
                p_form = ProfileUpdateForm(request.POST,request.FILES,instance=request.user.profilem)
                if u_form.is_valid and p_form.is_valid():
                        p_form.save()
                        u_form.save()
                        messages.success(request, f'Account Updated!')
                        return redirect('profile')
        else:
                u_form = UserUpdateForm(instance=request.user)
                p_form = ProfileUpdateForm(instance=request.user.profilem)
        name=request.user
        conpos= Story.objects.filter(author=name).count()
        thoco= thoughts.objects.filter(author=name).count()
        context={
                'u_form':u_form,
                'p_form': p_form,
                'countc':conpos,
                'countt':thoco,
                }
        return render(request,'users/profile.html',context)

class FeedbackCreateView(LoginRequiredMixin,CreateView,SuccessMessageMixin):
    model = feedback
    fields = ['content']
    success_url = '/profile/'
    success_message = "Thanks for your Feedback"
    def form_valid(self, form):
        form.instance.sender = self.request.user
        return super().form_valid(form)
@login_required
def allfeedbacks(request):
    name = request.user
    pid= feedback.objects.only('id')
    context = {
        'posts': feedback.objects.all().order_by('-date_posted'),
        'header': 'My Posts',
        'user': name,
        'p_id':pid,
    }
    return render(request, 'users/allfeedbacks.html', context)
def allreports(request):
    name = request.user
    pid= report.objects.only('id')
    context = {
        'posts': report.objects.all().order_by('-date_posted'),
        'header': 'My Posts',
        'user': name,
        'p_id':pid,
    }
    return render(request, 'users/allfeedbacks.html', context)

'''messages.debug
messages.info
messages.success
messages.warning
messages.error'''
class ReportCreateView(LoginRequiredMixin,CreateView,SuccessMessageMixin):
    model = report
    fields = ['against','msg']
    success_url = '/profile/'
    success_message = "Your Report has been registered"
    def form_valid(self, form):
        form.instance.sender = self.request.user
        return super().form_valid(form)

'''def action(request):
     user_id = request.POST.get('user_id')
     user = request.User
     ud = user.objects.filter(id=user_id)
     context={
         'user':ud,
     }
     return render(request,'users/action.html',context)'''

def userext(request):
       user_id = request.POST.get('username')
       userdet = User.objects.filter(id=user_id)
       name = request.POST.get('name')
       postdet = thoughts.objects.filter(author=name).order_by("-date_posted")
       thoco=thoughts.objects.filter(author=name).count()
       context = {
           'details':userdet, 
           'posts':postdet,
           'countt':thoco,
       }
       return render(request,'users/userexternal.html',context)
def privacy(request):
       return render(request,'users/privacy.html')

def action(request):
       return render(request,'users/action.html')
def seastory(request):
       return render(request,'users/storysearch.html')
def search(request):
    template='blog/allsearch.html'
    query = request.GET.get('q')

    if query:
        posts = thoughts.objects.filter(Q(cateogary__icontains=query) | Q(content__icontains = query)).order_by('-date_posted')
        if posts.count() ==0:
            messages.warning(request,'Nothing Found')
    else:
        posts = thoughts.objects.all().order_by('-date_posted')
        messages.warning(request,'Nothing Found!')
    return render(request,template,{'posts':posts,'countt':posts.count})

def usearch(request):
    query = request.POST.get('qn')
    if query:
        post = User.objects.filter(Q(username__icontains=query) | Q(first_name__icontains = query))
        if post.count() ==0:
            messages.error(request,'Nothing Found')
    else:
        messages.error(request,'Nothing Found!')
    context={
        'countt':post.count(),
        'posts':post
    }
    return render(request,'users/search.html',context)

def ssearch(request):
    template='users/ssearchresult.html'
    query = request.GET.get('q')

    if query:
        posts = Story.objects.filter(Q(title__icontains=query) | Q(content__icontains = query) | Q(writters__icontains = query)).order_by('-date_posted')
        if posts.count() ==0:
            messages.warning(request,'Nothing Found')
    else:
        posts = Story.objects.all().order_by('-date_posted')
        messages.warning(request,'Nothing Found!')
    return render(request,template,{'posts':posts,'countt':posts.count})