from django.urls import path
from django.conf.urls import url
from . import views
from .views import  (PostDetailView,ThoughtsDetailView, PostCreateView,
                     PostUpdateView,PostDeleteView,ThouCreateView,ThouUpdateView,
                     ThouDeleteView,StoDeleteView,StoUpdateView,StoDetailView,StoCreateView,StoListView
                     )

urlpatterns = [
    path('diary/', views.home, name='blog-home'),
    path('mythoughts/', views.mtho, name='blog-mtho'),
    path('stories',StoListView.as_view(),name='blog-story'),
    path('stories/mystories/', views.mystories, name='blog-mystory'),
    path('stories/new/', StoCreateView.as_view(), name='sto-create'),
    path('stories/<int:pk>/update/', StoUpdateView.as_view(), name='sto-update'),
    path('stories/<int:pk>/delete/', StoDeleteView.as_view(), name='sto-delete'),
    path('stories/<int:pk>/',StoDetailView.as_view() , name='sto-detail'),
    path('', views.tho_view, name='blog-feed'),
    path('diary/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('diary/new/', PostCreateView.as_view(), name='post-create'),
    path('diary/<int:pk>/update/', PostUpdateView.as_view(), name='post-update'),
    path('diary/<int:pk>/delete/', PostDeleteView.as_view(), name='post-delete'),
    path('quotes/new/', ThouCreateView.as_view(), name='quo-create'),
    path('quotes/<int:pk>/update/', ThouUpdateView.as_view(), name='quo-update'),
    path('qoutes/<int:pk>/delete/', ThouDeleteView.as_view(), name='quo-delete'),
    path('quotes/<int:pk>/',ThoughtsDetailView.as_view() , name='quo-detail'),
    path('like/', views.like, name='like'),
    path('create/', views.create, name='create'),
    path('like', views.like_view, name='likes'),
    path('comment', views.tho_det, name='comments'),
    path('addcomment', views.addcoom, name='addcomment'),   
]
    #path('confession_room/new/', ConfessCreateView.as_view(), name='con-create'),
    #path('confession_room/<int:pk>/update/', ConfessUpdateView.as_view(), name='con-update'),
    #path('confession_room/<int:pk>/delete/', ConfessDeleteView.as_view(), name='con-delete'),
    #path('myconfession/', views.confess, name='confess'),
    #path('confession_room/', ConfessListView.as_view(), name='conroom'),