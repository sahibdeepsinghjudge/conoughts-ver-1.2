from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponseRedirect,JsonResponse,HttpResponse
from django.urls import reverse
from .models import PostDiary,thoughts,Like,Comment,Story
from django.contrib.auth.models import User
from users.forms import UserUpdateForm
from .forms import StoryUpdateForm,ThoughtUpdateForm,DiaryUpdateForm
from django.contrib import messages
from django.views.generic import ListView, DetailView,CreateView,UpdateView,DeleteView,RedirectView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin,UserPassesTestMixin
from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger
from django.template.loader import render_to_string
from django.db.models import Count
#my diary
@login_required
def home(request):
    name = request.user
    name = request.user.first_name
    context = {
        'posts': PostDiary.objects.filter(author=name),
        'header': 'My Posts',
        'user': name,
        'status':'active',
    }
    return render(request, 'blog/myposts.html', context)

#mythoughts
@login_required
def mtho(request):
    name = request.user
    pid= thoughts.objects.only('id')
    post_id = request.POST.get('post_id')
    comments = Comment.objects.filter(post = post_id)
    context = {
        'posts': thoughts.objects.filter(author=name).order_by('-date_posted'),
        'header': 'My Posts',
        'user': name,
        'p_id':pid,
        'coms':comments
    }
    return render(request, 'blog/allthoughts.html', context)


#diary related

'''class PostListView(ListView):
    model = PostDiary
    template_name = 'blog/myposts.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']'''
class PostDetailView(DetailView):
    model = PostDiary
    

class PostCreateView(LoginRequiredMixin,CreateView):
    model = PostDiary
    fields = ['content',]
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)
        

class PostUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model = PostDiary
    fields = ['content',]
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False
class PostDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model = PostDiary
    fields = ['content',]
    success_url='/'
    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False
'''def about(request):
    name = request.user
    context = {
        'header': 'All Posts',
        'posts': PostDiary.objects.filter(author=name),
    }
    return render(request, 'blog/all.html', context)'''
# filter(author=name)
#thoughts related

'''class ThoughtsListView(ListView):
    model = thoughts
    template_name = 'blog/all.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']'''
    
def tho_view(request):
    qs = thoughts.objects.all().order_by('-date_posted')
    pid= thoughts.objects.only('id')
    post_id = request.POST.get('post_id')
    posts = Comment.objects.filter(post=post_id).count()
    print(posts)
    user = request.user
    context = {
        'posts':qs,
        'user':user,
        'pk':pid,
        'cont':posts
    }    
    return render(request,'blog/all.html',context)

@login_required
def like(request):
    user = request.user
    if request.method=='POST':
        post_id = request.POST.get('post_id')
        post_obj = thoughts.objects.get(id=post_id)
        if user in post_obj.liked.all():
            post_obj.liked.remove(user)
            
        else:
            post_obj.liked.add(user)
            
        like,created = Like.objects.get_or_create(user=user,post_id=post_id)
        if not created:
            if like.value == 'Like':
               like.value='Unlike'
               
            else:
                like.value='Like'
        like.save()
        return redirect('blog-feed')        

class ThoughtsDetailView(DetailView):
    model = thoughts
@login_required
def tho_det(request):
    post_id = request.POST.get('post_id')
    posts = thoughts.objects.filter(id=post_id)
    comments = Comment.objects.filter(post=post_id).annotate(cont=Count('usera'))
    context={
        'posts':posts,
        'coms':comments,
    }
    return render(request,'blog/tho_det.html',context) 
class ThouCreateView(LoginRequiredMixin,CreateView):
    model = thoughts
    fields = ['cateogary','content']
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)
        

class ThouUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model = thoughts
    fields = ['cateogary','content']
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False
class ThouDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model = thoughts
    fields = ['cateogary','content']
    success_url='/mythoughts/'
    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False



#confession starts


def create(request):
    return render(request,'blog/default.html')

def like_view(request):
    post_id = request.POST.get('post_id')
    likes = Like.objects.filter(post=post_id)
    post = thoughts.objects.filter(id=post_id)
    coments=Comment.objects.filter(post=post_id).annotate( article_count=Count('usera')).values('article_count')
    coment=Comment.objects.filter(post=post_id)
    context={
        'likeu':likes,
        'posts':post,
        'comt':coments,
        'coms':coment,
    }
    return render(request,'blog/likes.html',context)
@login_required
def addcoom(request):
    user = request.user
    if request.method=='POST':
        post_obj = thoughts.objects.get(id=request.POST.get('post_id'))
      
        if user in post_obj.comments.all():
            messages.success(request, f'Comment added again')
        else:
            post_obj.comments.add(user)
            Comment.objects.create(post=request.POST.get('post_id'),usera=user,value=request.POST.get('comment_user'))
            messages.success(request, f'Comment added !')
    else:
        messages.warning(request, f'Comment not added')
    
    return redirect('blog-feed')

'''def storydraft(request):
    user=request.user
    if request.method=='POST':
        auth=user
        coverpage=request.POST.get('coverimg')
        content=request.POST.get('content')
        storydraft.objects.create(author=auth,coverpage=coverpage,content=content)
        messages.success(request, f'Story is saved to drafts!')
    else:
        messages.info(request, f'Story not saved to drafts')
    
    return redirect('blog-story')'''

class StoDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model = Story
    fields = ['content','coverpage','author']
    success_url='/stories/mystories'
    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False

class StoUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model = Story
    fields = ['title','writters','coverpage','overview','content']
    
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post= self.get_object()
        if self.request.user == post.author:
            return True
        else:
            return False

class StoCreateView(LoginRequiredMixin,CreateView):
    model = Story
    fields = ['title','writters','coverpage','overview','content']
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

class StoDetailView(DetailView):
    model = Story

class StoListView(LoginRequiredMixin,ListView):
    model = Story
    template_name = 'blog/conroom.html'
    context_object_name = 'posts'
    ordering = ['-date_posted']
    fields = ['content','coverpage','date_posted','author']
    paginate_by = 3


def mystories(request):
    posts=Story.objects.filter(author=request.user).order_by('-date_posted')
    context={
        'posts':posts
    }
    return render(request,'blog/mystories.html',context)

def page_not_found(request,exception):
    return render(request,'blog/404.html')

def server_error(request):
    return render(request,'blog/500.html')
