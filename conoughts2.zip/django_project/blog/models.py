#dialy diary
from django.urls import reverse
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
class PostDiary(models.Model):
    author = models.OneToOneField(User, on_delete=models.CASCADE)
    content = models.TextField()
    date_created = models.DateTimeField(default=timezone.now)#auto_now_add=True
    def __str__(self):
        return f'{self.author.username } diary'
    def get_absolute_url(self):
        return reverse('blog-home')

class thoughts(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    liked = models.ManyToManyField(User,related_name='likes',blank=True)
    comments = models.ManyToManyField(User,related_name='comment',blank=True)
    cateogary=models.CharField(max_length=100)
    date_posted = models.DateTimeField(default=timezone.now)
    date_updated = models.DateTimeField(auto_now=True)
    #auto_now_add=True

    def __str__(self):
        return str(self.cateogary)
    def get_absolute_url(self):
        return reverse('blog-feed')
    def num_likes(self):
        return self.liked.all().count()
    def num_comments(self):
        return self.comments.all().count()

LIKE_CHOICES = (
    ('Like','Like'),
    ('Unike','Unike'),
) 
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(thoughts, on_delete=models.CASCADE)
    value = models.CharField(choices=LIKE_CHOICES,default='Like',max_length=10)  

    def __str__(self):
        return str(self.post)

class Comment(models.Model):
    usera = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user')
    post = models.IntegerField()
    value = models.TextField(blank=True)
    date_posted = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return str (self.usera)

class Story(models.Model):
    author= models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=25,null=False,blank=False,default="Your Story Title")
    writters = models.CharField( max_length=25,null=False,blank=False, default="Writer of the story")
    overview=models.CharField(max_length=125,null=False,blank=False,default="Overview")
    coverpage=models.ImageField(default='icecream.jpg', upload_to='cover_pics')
    content = models.TextField()
    date_posted = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return f'{self.author.username } "s story'
    def get_absolute_url(self):
        return reverse('blog-story')