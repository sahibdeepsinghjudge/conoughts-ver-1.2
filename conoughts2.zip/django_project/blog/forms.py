from django import forms
from .models import Story,PostDiary,thoughts

class StoryUpdateForm(forms.ModelForm):
    class Meta:
        model = Story
        fields = ['title','writters','coverpage','overview','content']
class DiaryUpdateForm(forms.ModelForm):
    class Meta:
        model = PostDiary
        fields = ['content','date_created']
class ThoughtUpdateForm(forms.ModelForm):
    class Meta:
        model = thoughts
        fields = ['content','cateogary']
