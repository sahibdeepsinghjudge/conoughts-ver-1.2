from django.contrib import admin
from .models import PostDiary,thoughts,Like,Comment,Story

admin.site.register(PostDiary)
admin.site.register(thoughts)

admin.site.register(Like)
admin.site.register(Comment)
admin.site.register(Story)


